import hashlib
import user
import exceptions

class Authenticator:
    def __init__(self):
        self.users = [] #inctance of user.User

    def add_user(self, username, password):
        usernames = []
        for i in self.users:
            usernames.append(i.username)
        
        if username in usernames:
            raise exceptions.UsernameAlreadyExists()
        elif len(password) < 8:
            raise exceptions.PasswordTooShort()
        else:
            password = password.encode()
            password = hashlib.md5(password).hexdigest()
            new_user = user.User(username, password)
            self.users.append(new_user) 


    def login(self, username, password):
        for user in self.users:
            hash_pass = hashlib.md5(password.encode()).hexdigest()
            info = [user.username, user.password]
            if username in info and hash_pass != info[1]: # password not in info:
                raise exceptions.InvalidPassword()
            elif hash_pass == info[1] and username not in info:
                raise exceptions.InvalidUsername()
            elif username in info and hash_pass == info[1]:
                user.is_logged_in = True
                return True
            else:
                raise exceptions.InvalidUsername()
        


    def is_logged_in(self, username):
        for user in self.users:
            if username == user.username:
                return user.is_logged_in




