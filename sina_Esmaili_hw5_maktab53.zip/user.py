class User:
    def __init__(self, username, password, is_logged_in=False):
        self.username = username
        self.password = password
        self.is_logged_in = is_logged_in

    def __repr__(self) -> str:
        return self.password