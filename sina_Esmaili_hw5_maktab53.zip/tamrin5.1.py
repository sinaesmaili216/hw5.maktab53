def sed(file_input, file_output, replacement_string, pattern_string=None):
    try:
        with open(file_input) as f:
            content = f.read()
    except FileNotFoundError:
        print('file is no exist')
        return
    
    if pattern_string in content:
        content = content.replace(pattern_string, replacement_string)

    try:
        with open(file_output, 'a') as f:
            f.write(content)
    except FileNotFoundError:
        with open(file_output, 'w') as f:
            f.write(content) 

